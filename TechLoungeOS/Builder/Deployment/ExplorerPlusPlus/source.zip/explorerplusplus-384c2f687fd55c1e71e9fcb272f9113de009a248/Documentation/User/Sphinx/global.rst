.. role:: bolditalic
  :class: bolditalic